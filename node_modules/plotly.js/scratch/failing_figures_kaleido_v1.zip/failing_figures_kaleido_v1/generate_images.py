import json
import os
import traceback

import plotly.io as pio

mock_names = [
    "gl3d_streamtube_reversed_ranges",
    "mathjax",
]

for mock_name in mock_names:

    mock_filepath = os.path.join("mocks", f"{mock_name}.json")
    out_dir = "baselines"

    with open(mock_filepath, "r") as f:
        fig = json.load(f)

        width = 700
        height = 500
        if "layout" in fig:
            layout = fig["layout"]
            if "autosize" not in layout or layout["autosize"] != True:
                if "width" in layout:
                    width = layout["width"]
                if "height" in layout:
                    height = layout["height"]

        print("=============")
        try:
            pio.write_image(
                fig=fig,
                file=os.path.join(out_dir, mock_name + ".png"),
                width=width,
                height=height,
                validate=False,
            )
            print(f"=== Successfully generated image for {mock_name} ===")
        except Exception as e:
            print(f"=== Failed to generate image for {mock_name} ===")
            print("=============")
            traceback.print_exc()
        finally:
            print("=============")
